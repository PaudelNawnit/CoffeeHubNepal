# Images to Convert to WebP

This folder contains all PNG and JPEG images that need to be converted to WebP format.

## Images Included (20 total)

### Logo Images (6)
- `coffeelogo.png` - Main logo
- `coffee logo.jpg` - Alternative logo
- `android-chrome-512x512.png` - Android Chrome icon
- `favicon-16x16.png` - Small favicon
- `favicon-32x32.png` - Medium favicon
- `logo.png` - General logo

### Team Member Images (12)
- `SurajNepal.png`
- `SarthakBhattarai.png`
- `SiddhantGiri.jpeg`
- `KrrishNyoupane.png`
- `SachinJha.png`
- `MukeshPandey.png`
- `NawnitPaudel.png`
- `SupriyaKhadka.png`
- `RajdipJoshi.png`
- `AasthaGaire.png`
- `PradipKhanal.png`
- `AdityaManShrestha.png`

### Landing Page Images (2)
- `coffee.png` - Coffee image
- `farmers-handshake.png` - Farmers handshake image

## Conversion Instructions

### Option 1: Online Converter (Easiest)
1. Visit https://convertio.co/png-webp/ or https://cloudconvert.com/png-to-webp
2. Upload each image file
3. Download the converted `.webp` file
4. Place the converted files back in their original locations:
   - Logo images → `apps/web/src/assets/images/logo/`
   - Team images → `apps/web/src/assets/images/team/`
   - Landing images → `apps/web/src/assets/images/landing/`
   - Root images → `apps/web/src/assets/images/`

### Option 2: Command Line (ImageMagick)
```bash
# Install ImageMagick first: https://imagemagick.org/script/download.php

# Navigate to this folder
cd apps/web/src/assets/images/images-to-convert

# Convert all PNG files
for file in *.png; do
  magick "$file" "${file%.png}.webp"
done

# Convert JPEG files
for file in *.jpeg *.jpg; do
  magick "$file" "${file%.*}.webp"
done
```

### Option 3: Node.js Script (Sharp)
If you have Sharp installed:
```bash
npm install sharp --save-dev
```

Then create a conversion script or use an online batch converter.

## After Conversion

1. **Move converted files** to their original directories:
   - `coffeelogo.webp` → `logo/coffeelogo.webp`
   - `SurajNepal.webp` → `team/SurajNepal.webp`
   - etc.

2. **Keep original PNG/JPEG files** as backup (or delete them after verifying WebP works)

3. **Verify** that all code references are updated (already done - all imports now use `.webp`)

## File Size Benefits

WebP typically provides:
- **25-35% smaller file sizes** compared to PNG/JPEG
- Same or better visual quality
- Supported by all modern browsers

## Notes

- The code has already been updated to reference `.webp` files
- Old PNG/JPEG files can be deleted after conversion and testing
- `favicon.ico` should remain as `.ico` format (not converted)
